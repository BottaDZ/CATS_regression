## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(CATSregression)
data("Raevel")

## ----str_data-----------------------------------------------------------------
str(Raevel)

## ----data_select--------------------------------------------------------------
comm<-Raevel$comm
traits<-log(Raevel$traits[,1:3])
means.abund<-colMeans(Raevel$comm)

## ----model1-------------------------------------------------------------------
m1<-CATSregression(comm,traits,est.prior=F)

## ----diagplot, echo =FALSE, fig.height=3.5------------------------------------
par(mai=c(0.82, 0.82, 0.2, 0.42))
plot(m1,log="x")

## ----model2-------------------------------------------------------------------
m2<-CATSregression(comm,traits,family="nb",est.prior=F)
plot(m2,log="x")

## ----Rsquared-----------------------------------------------------------------
par(mfrow=c(1,2))
boxplot(m2$R.sq,main="R-Squared")
boxplot(m2$R.sq.adj,main="Adjusted R-squared")
abline(h=0,col="red")
par(mfrow=c(1,1))

## ----check.model2-------------------------------------------------------------
CATSregression:::checkCATS(m2)

## ----anova--------------------------------------------------------------------
anova2<-anova(m2)

## ----anova2-------------------------------------------------------------------
anova2[[1]]

## ----extract.p----------------------------------------------------------------
p.values<-extract.pvalues(anova2)
head(p.values)

## ----p2asterisk---------------------------------------------------------------
head(symnum(p.values, corr = FALSE, na = FALSE, 
       cutpoints = c(0,0.001, 0.01, 0.05, 0.1, 1), 
       symbols = c("***", "**", "*", ".", "NS")))

## ----coef---------------------------------------------------------------------
#plot(coef(m2)[,"SLA"]~Raevel$envir$Height,xlab="Height",ylab="coef. of SLA",
#     pch=c(1,19)[as.numeric(p.values[,"SLA"]<=0.05)+1])

